<?php
	require "pdml.php";
?>
<pdml>
 <body>
  <font face="Arial" size="16pt">Hello, World</font>
 </body>
</pdml>
